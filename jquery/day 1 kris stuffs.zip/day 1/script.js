$(document).ready(function() {
    var myAttributes = {};
    $('img').click(function(){
        console.log('source data', $(this).attr("src"))        
        console.log('alt source data', $(this).attr("data-alt-src"))
        myAttributes = {
            'src': $(this).attr("data-alt-src"), 
            'data-alt-src': $(this).attr("src")
        }
        console.log(myAttributes)
        $(this).attr(myAttributes);
    })
    $('body').on('click', 'button', function(){
        $('body').append('<button>New Button</button>')
    })
});